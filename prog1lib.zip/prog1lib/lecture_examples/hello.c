/*
Compile: make hello
Run: ./hello
make hello && ./hello
*/
 
#include <stdio.h>

int main(void) {
    printf("hello, world\n");
    return 0;
}
